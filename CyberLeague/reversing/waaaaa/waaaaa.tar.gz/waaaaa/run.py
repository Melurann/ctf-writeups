from http.server import SimpleHTTPRequestHandler, HTTPServer


class CustomHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Cross-Origin-Embedder-Policy", "require-corp")
        super().end_headers()


PORT = 8000


def run(server_class=HTTPServer, handler_class=CustomHandler):
    server_address = ("", PORT)
    httpd = server_class(server_address, handler_class)
    print(f"Serving on http://localhost:{PORT}")
    httpd.serve_forever()


if __name__ == "__main__":
    run()
