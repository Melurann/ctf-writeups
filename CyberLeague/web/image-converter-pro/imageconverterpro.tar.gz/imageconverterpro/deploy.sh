#!/bin/sh

check() {
  echo -e "\e[1;34m[+] Verifying Challenge Integrity\e[0m"
  sha256sum -c sha256sum 2>/dev/null || echo "sha256sum file not found, skipping integrity check"
}

build_container() {
  echo -e "\e[1;34m[+] Building Challenge Docker Container\e[0m"
  docker build -t localhost/chall-imageconverterpro --platform linux/amd64 .
}

run_container() {
  FLAG="FLG{FAKE_FLAG_FOR_TESTING}"
  echo -e "\e[1;32m[+] Using Flag: ${FLAG}\e[0m"
  echo -e "\e[1;34m[+] Running Challenge Docker Container on 127.0.0.1:1337\e[0m"
  docker run --name chall-imageconverterpro --rm -e FLAG="${FLAG}"  -p 127.0.0.1:1337:1337 -t -i -e HOST=127.0.0.1 -e PORT=1337 -e TIMEOUT=30 --read-only --privileged --platform linux/amd64 localhost/chall-imageconverterpro
}

kill_container() {
	docker ps --filter "name=chall-imageconverterpro" --format "{{.ID}}" \
		| tr '\n' ' ' \
		| xargs docker stop -t 0 \
		|| true
}

case "${1}" in
  "check")
    check
    ;;
  "build")
    build_container
    ;;
  "run")
    run_container
    ;;
  "kill")
    kill_container
    ;;
  *)
    check
    build_container
    run_container
    ;;
esac
