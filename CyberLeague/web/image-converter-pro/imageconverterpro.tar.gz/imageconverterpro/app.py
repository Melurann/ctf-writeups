#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Respect the shebang and mark file as executable

import os
from functools import wraps
from io import BytesIO

from cairosvg import svg2png
from flask import (
    Flask,
    flash,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)
from flask_login import (
    LoginManager,
    UserMixin,
    current_user,
    login_required,
    login_user,
    logout_user,
)
from flask_sqlalchemy import SQLAlchemy
from waitress import serve
from werkzeug.security import check_password_hash, generate_password_hash

ALLOWED_EXTENSIONS = {"svg"}
SAFE = True


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def verified_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not session.get("verified"):
            flash("You must be verified to access this page.", "danger")
            return redirect(url_for("home"))
        return f(*args, **kwargs)

    return decorated_function


app = Flask(__name__)
app.config["SECRET_KEY"] = f"{'_securetoken'[::-1]}{os.urandom(2).hex()}"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = True

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(256), nullable=False)
    verified = db.Column(db.Boolean, default=True)


with app.app_context():
    db.create_all()

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


@app.route("/")
def home():
    return render_template("index.html", user=current_user)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        confirm_password = request.form["confirm_password"]

        if password != confirm_password:
            flash("Passwords do not match!", "danger")
            return redirect(url_for("register"))

        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash("Username already taken!", "danger")
            return redirect(url_for("register"))

        hashed_password = generate_password_hash(password, method="pbkdf2:sha256")

        new_user = User(username=username, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        flash("Registration successful! You can now log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            session["verified"] = user.verified

            flash("Login successful!", "success")
            return redirect(url_for("home"))
        else:
            flash("Invalid credentials, please try again.", "danger")
            return redirect(url_for("login"))

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Logged out successfully!", "info")
    return redirect(url_for("login"))


@app.route("/converter", methods=["GET", "POST"])
@verified_required
def converter():
    if request.method == "GET":
        return render_template("converter.html")
    elif request.method == "POST":
        if "file" not in request.files:
            flash("No file selected.", "danger")
            return render_template("converter.html")

        file = request.files["file"]

        if not file or not allowed_file(file.filename):
            flash("Invalid file type.", "danger")
            return render_template("converter.html")

        if file.filename == "":
            flash("No file selected.", "danger")
            return render_template("converter.html")

        content = file.read()
        output = BytesIO()

        try:
            svg2png(bytestring=content, write_to=output, unsafe=SAFE)
            output.seek(0)
        except Exception as e:
            flash(str(e), "danger")
            return render_template("converter.html")

        return send_file(
            output,
            mimetype="image/png",
            as_attachment=True,
            download_name="converted.png",
        )


serve(app, host="0.0.0.0", port=1337)
